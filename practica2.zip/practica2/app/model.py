

from pickleshare import *

db = PickleShareDB('miBD')

def nuevousuario(nombre,psw):
    
    db[nombre] = {'psw':psw}
    return True

def leerbd(nombre):
    return db[nombre]['psw']

def exiteuser(nombre):
    if nombre in db:
        return True
    else:
        return False

def modificar(nombre,nombrenuevo,psw):
    db[nombrenuevo] = db[nombre]
    del db[nombre]
    db[nombrenuevo] = {'psw':psw}
    return True